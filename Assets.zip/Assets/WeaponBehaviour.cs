using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponBehaviour : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject bulletPrefab;
    public float accuracy;
    public float rateOfFireSeconds;
    public float numberOfProjectiles;
    private float secondsSinceLastShot;
    void Start()
    {
        secondsSinceLastShot = rateOfFireSeconds;
    }

    // Update is called once per frame
    void Update()
    {
        secondsSinceLastShot += Time.deltaTime;
    }

    public void Fire(Vector3 targetPosition)
    {

        if (secondsSinceLastShot >= rateOfFireSeconds)
        {
            //Game is now Shooting Bullet
            for (int i=0; i < numberOfProjectiles; i++)
            {
            GameObject newBullet = Instantiate(bulletPrefab, transform.position + transform.forward, transform.rotation);

            //Offset bullet direction
            
            float inaccuracy = Vector3.Distance(transform.position, targetPosition) / accuracy;
            Vector3 inaccuratePosition = targetPosition;
            inaccuratePosition.x += Random.Range(-inaccuracy, inaccuracy);
            inaccuratePosition.z += Random.Range(-inaccuracy, inaccuracy);
            
            newBullet.transform.LookAt(targetPosition);
    
            secondsSinceLastShot = 0;
            }
        }
    }
}
