using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionBehaviour : MonoBehaviour
{
    public float secondsToExist;
    private float explosionTimer;
    // Start is called before the first frame update
    void Start()
    {
        explosionTimer = 0;
    }

    // Update is called once per frame
   private void FixedUpdate()
    {
        explosionTimer += Time.deltaTime;

        float lifeFraction = explosionTimer / secondsToExist;
        Vector3 maxScale = Vector3.one * 5;
        transform.localScale = Vector3.Lerp(Vector3.zero, maxScale, lifeFraction); //Linear Interpolation, linear scaling between values = LERP

        if (explosionTimer >= secondsToExist)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider collision)
    {
        HealthSystem theirHealthSystem = collision.gameObject.GetComponent<HealthSystem>();
        if (theirHealthSystem != null)
        {
            theirHealthSystem.TakeDamage(10);
        }
    }
}
