using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{

    public GameObject enemyPrefab;
    public float spawnDelay;
    float secondsSinceLastSpawn;

    public float startDelay;
    public GameObject spawnPoint;
    // Start is called before the first frame update
    void Start()
    {

        secondsSinceLastSpawn = 0;
    }

    // Update is called once per frame
    //Fixed update happens the same number of times across players.
    private void FixedUpdate()
    {
        if(startDelay > 0)
        {
            startDelay -= Time.deltaTime;
        }else if (startDelay < 0)
        {
            secondsSinceLastSpawn += Time.fixedDeltaTime;
            if (secondsSinceLastSpawn >= spawnDelay)
            {
                Instantiate(enemyPrefab, spawnPoint.transform.position, spawnPoint.transform.rotation);
                secondsSinceLastSpawn = 0;
            }
        }
        /*secondsSinceLastSpawn += Time.fixedDeltaTime;
        if (secondsSinceLastSpawn >= spawnDelay)
        {
            Instantiate(enemyPrefab, spawnPoint.transform.position, spawnPoint.transform.rotation);
            secondsSinceLastSpawn = 0;
        }*/
    }
}
