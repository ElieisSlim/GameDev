using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthSystem : MonoBehaviour
{
    public float health;

    public float maxHealth;
    public GameObject healthBarPrefab;

    public GameObject deathEffect;
    HealthBar myHealthBar;
    private ScoreSystem scoreSystem;

    void Start()
    {
        health = maxHealth;
        GameObject healthBarObject = Instantiate(healthBarPrefab, References.canvas.transform);
        myHealthBar = healthBarObject.GetComponent<HealthBar>();
        scoreSystem = FindObjectOfType<ScoreSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        myHealthBar.ShowHealthFraction(health / maxHealth);
        myHealthBar.transform.position = Camera.main.WorldToScreenPoint(transform.position) + Vector3.up * 30;
    }

    public void TakeDamage(float damageTotal)
    {
        if(health > 0)
        {

            health -= damageTotal;
            if (health <= 0)
            {
                if (deathEffect != null)
                {
                    Instantiate(deathEffect, transform.position, transform.rotation);
                }
                if (scoreSystem != null)
                {
                    scoreSystem.AddScore((float)maxHealth);
                }
                scoreSystem.AddScore((float)maxHealth);
                Destroy(gameObject);
            }
        }
    }

    public void OnDestroy()
    {
        if(myHealthBar != null)
        {
            Destroy(myHealthBar.gameObject);
        }

    } 
}
