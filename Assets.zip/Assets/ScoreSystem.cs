using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreSystem : MonoBehaviour
{
    public float score;
    public Text scoreText;
    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        UpdateScoreUI(score);
    }

    void Update()
    {
        UpdateScoreUI(score);
    }

    // Update is called once per frame
    public void AddScore(float points)
    {
        score += points;
        Debug.Log("Score: " + score);
    }

    void UpdateScoreUI(float score)
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + score.ToString();
        }
    }
}
