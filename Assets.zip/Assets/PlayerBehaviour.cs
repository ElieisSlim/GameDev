using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBehaviour : MonoBehaviour
{
    //INSPECTOR EDITS PUBLIC VARIABLES
    public float speed;
    // Start is called before the first frame update
    public List<WeaponBehaviour> weapons = new List<WeaponBehaviour>();
    //Below variable numbered index of the list
    public int selectedWeapon;

    void Start()
    {
        References.thePlayer = gameObject;
        selectedWeapon = 0;
    }

    // Update is called once per frame
    void Update()
    {
        //MOVEMENT
        //Where we are
        Vector3 inputVector = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        Rigidbody rigidBody = GetComponent<Rigidbody>();
        rigidBody.velocity = inputVector * speed;

        //Follow Mouse Cursor in 3D Space
        Ray rayCameraToCursor = Camera.main.ScreenPointToRay(Input.mousePosition);
        Plane playerPlane = new Plane(Vector3.up, transform.position);
        playerPlane.Raycast(rayCameraToCursor, out float distanceFromCamera);
        Vector3 cursorPosition = rayCameraToCursor.GetPoint(distanceFromCamera);


        Vector3 lookAtPosition = cursorPosition;
        transform.LookAt(lookAtPosition); //Face the new position

        

        //Shooting Bullets
        //secondsSinceLastShot += Time.deltaTime;
        if (weapons.Count > 0 && Input.GetButton("Fire1"))
        {
            weapons[selectedWeapon].Fire(cursorPosition);
        }

        if (Input.GetButtonDown("Fire2"))
        {
            ChangeWeaponIndex(selectedWeapon + 1);
        }
    }

    private void ChangeWeaponIndex(int index)
    {
        selectedWeapon = index;

        //If indexing has gone too far it should circle back around
        if (selectedWeapon >= weapons.Count)
        {
            selectedWeapon = 0;
        }

        for (int i = 0; i < weapons.Count; i++)
        {
            if (i == selectedWeapon)
            {
                weapons[i].gameObject.SetActive(true); // If it is our current weapon turn on
            }else
            {
                weapons[i].gameObject.SetActive(false); //else turn off
            }
        }
    }

    private void OnTriggerEnter(Collider other)
        {
            WeaponBehaviour theirWeapon = other.GetComponentInParent<WeaponBehaviour>();
            if (theirWeapon != null)
            {
                weapons.Add(theirWeapon);
                theirWeapon.transform.position = transform.position;
                theirWeapon.transform.rotation = transform.rotation;
                theirWeapon.transform.SetParent(transform);
                ChangeWeaponIndex(weapons.Count - 1);
            }
        }
}
